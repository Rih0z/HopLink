<?php
/**
 * ショートコード管理クラス
 */
class HopLink_Shortcode {
    
    private $api;
    
    public function __construct() {
        $this->api = new HopLink_API();
    }
    
    /**
     * ショートコード登録
     */
    public function register() {
        add_shortcode('hoplink', array($this, 'render_shortcode'));
        add_shortcode('hoplink_auto', array($this, 'render_auto_shortcode'));
    }
    
    /**
     * ショートコードレンダリング
     * 使用例: [hoplink keyword="クラフトビール" platform="all" limit="3"]
     */
    public function render_shortcode($atts) {
        $atts = shortcode_atts(array(
            'keyword' => '',
            'platform' => 'all', // all, rakuten, amazon
            'limit' => 3,
            'layout' => 'grid' // grid, list
        ), $atts);
        
        if (empty($atts['keyword'])) {
            return '<p>キーワードを指定してください。</p>';
        }
        
        // 商品検索
        $products = $this->api->search_all($atts['keyword'], $atts['platform']);
        
        if (empty($products)) {
            return '<p>商品が見つかりませんでした。</p>';
        }
        
        // 表示数制限
        $products = array_slice($products, 0, intval($atts['limit']));
        
        // HTML生成
        ob_start();
        ?>
        <div class="hoplink-container hoplink-<?php echo esc_attr($atts['layout']); ?>">
            <?php foreach ($products as $product): ?>
                <div class="hoplink-product">
                    <div class="hoplink-product-image">
                        <?php if (!empty($product['image'])): ?>
                            <img src="<?php echo esc_url($product['image']); ?>" 
                                 alt="<?php echo esc_attr($product['title']); ?>"
                                 loading="lazy">
                        <?php endif; ?>
                    </div>
                    
                    <div class="hoplink-product-info">
                        <h3 class="hoplink-product-title">
                            <?php echo esc_html($this->truncate_title($product['title'], 50)); ?>
                        </h3>
                        
                        <div class="hoplink-product-meta">
                            <span class="hoplink-price">
                                ¥<?php echo number_format($product['price']); ?>
                            </span>
                            
                            <?php if ($product['review'] > 0): ?>
                                <span class="hoplink-review">
                                    ★<?php echo number_format($product['review'], 1); ?>
                                </span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="hoplink-product-shop">
                            <?php echo esc_html($product['shop']); ?>
                        </div>
                        
                        <a href="<?php echo esc_url($product['url']); ?>" 
                           class="hoplink-button"
                           target="_blank"
                           rel="sponsored noopener">
                            詳細を見る
                        </a>
                    </div>
                    
                    <div class="hoplink-platform-badge hoplink-<?php echo esc_attr($product['platform']); ?>">
                        <?php echo $product['platform'] === 'rakuten' ? '楽天' : 'Amazon'; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <div class="hoplink-disclosure">
            ※本記事はアフィリエイト広告を含んでいます。
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * タイトル省略
     */
    private function truncate_title($title, $length = 50) {
        if (mb_strlen($title) > $length) {
            return mb_substr($title, 0, $length) . '...';
        }
        return $title;
    }
    
    /**
     * 自動解析ショートコード
     * 使用例: [hoplink_auto] または [hoplink_auto limit="5" platform="all"]
     */
    public function render_auto_shortcode($atts) {
        global $post;
        
        if (!$post) {
            return '<p>記事内容を解析できませんでした。</p>';
        }
        
        $atts = shortcode_atts(array(
            'limit' => 3,
            'platform' => 'all',
            'layout' => 'grid'
        ), $atts);
        
        // アナライザークラスを読み込み
        require_once HOPLINK_PLUGIN_DIR . 'includes/class-hoplink-analyzer.php';
        $analyzer = new HopLink_Analyzer();
        
        // 記事から商品を自動取得
        $products = $analyzer->get_products_for_post($post->ID, intval($atts['limit']));
        
        if (empty($products)) {
            // キーワードが見つからない場合は、タイトルから検索
            $keywords = explode(' ', $post->post_title);
            if (!empty($keywords[0])) {
                $products = $this->api->search_all($keywords[0], $atts['platform']);
                $products = array_slice($products, 0, intval($atts['limit']));
            }
        }
        
        // それでも見つからない場合は、フォールバック検索
        if (empty($products)) {
            $extracted_keywords = $analyzer->extract_keywords($post->post_title . ' ' . $post->post_content, 5);
            $fallback_keywords = $analyzer->get_fallback_keywords($extracted_keywords);
            
            foreach ($fallback_keywords as $fallback_keyword) {
                $products = $this->api->search_all($fallback_keyword, $atts['platform']);
                if (!empty($products)) {
                    $products = array_slice($products, 0, intval($atts['limit']));
                    break;
                }
            }
        }
        
        // 最終的なフォールバック：設定されたキーワードまたはデフォルト
        if (empty($products)) {
            $fallback_keyword = get_option('hoplink_fallback_keyword', 'クラフトビール 贈り物');
            $products = $this->api->search_all($fallback_keyword, $atts['platform']);
            $products = array_slice($products, 0, intval($atts['limit']));
        }
        
        if (empty($products)) {
            return '<p>関連商品が見つかりませんでした。</p>';
        }
        
        // HTML生成（通常のショートコードと同じ）
        ob_start();
        ?>
        <div class="hoplink-container hoplink-<?php echo esc_attr($atts['layout']); ?> hoplink-auto">
            <h3 class="hoplink-auto-title">この記事で紹介した商品</h3>
            <?php foreach ($products as $product): ?>
                <div class="hoplink-product">
                    <div class="hoplink-product-image">
                        <?php if (!empty($product['image'])): ?>
                            <img src="<?php echo esc_url($product['image']); ?>" 
                                 alt="<?php echo esc_attr($product['title']); ?>"
                                 loading="lazy">
                        <?php endif; ?>
                    </div>
                    
                    <div class="hoplink-product-info">
                        <h3 class="hoplink-product-title">
                            <?php echo esc_html($this->truncate_title($product['title'], 50)); ?>
                        </h3>
                        
                        <div class="hoplink-product-meta">
                            <span class="hoplink-price">
                                ¥<?php echo number_format($product['price']); ?>
                            </span>
                            
                            <?php if ($product['review'] > 0): ?>
                                <span class="hoplink-review">
                                    ★<?php echo number_format($product['review'], 1); ?>
                                </span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="hoplink-product-shop">
                            <?php echo esc_html($product['shop']); ?>
                        </div>
                        
                        <a href="<?php echo esc_url($product['url']); ?>" 
                           class="hoplink-button"
                           target="_blank"
                           rel="sponsored noopener">
                            詳細を見る
                        </a>
                    </div>
                    
                    <div class="hoplink-platform-badge hoplink-<?php echo esc_attr($product['platform']); ?>">
                        <?php echo $product['platform'] === 'rakuten' ? '楽天' : 'Amazon'; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <div class="hoplink-disclosure">
            ※本記事はアフィリエイト広告を含んでいます。
        </div>
        <?php
        return ob_get_clean();
    }
}