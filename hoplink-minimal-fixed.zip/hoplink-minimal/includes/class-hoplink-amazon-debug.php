<?php
/**
 * Amazon PA-API v5 デバッグクラス
 * 
 * PA-API v5の認証エラーやアクセス制限に関する詳細なデバッグ情報を提供します。
 * 
 * @since 1.0.0
 */
class HopLink_Amazon_Debug {
    
    /**
     * API認証情報の検証
     */
    public static function validate_credentials() {
        $access_key = get_option('hoplink_amazon_access_key');
        $secret_key = get_option('hoplink_amazon_secret_key');
        $partner_tag = get_option('hoplink_amazon_partner_tag');
        
        $issues = array();
        
        // アクセスキーの形式チェック（通常20文字）
        if (strlen($access_key) !== 20) {
            $issues[] = 'アクセスキーの長さが不正です（20文字である必要があります）';
        }
        
        // アクセスキーの形式チェック（AKで始まる）
        if (substr($access_key, 0, 2) !== 'AK') {
            $issues[] = 'アクセスキーの形式が不正です（AKで始まる必要があります）';
        }
        
        // シークレットキーの形式チェック（通常40文字）
        if (strlen($secret_key) !== 40) {
            $issues[] = 'シークレットキーの長さが不正です（40文字である必要があります）';
        }
        
        // パートナータグの形式チェック
        if (!preg_match('/^[a-zA-Z0-9\-]+$/', $partner_tag)) {
            $issues[] = 'パートナータグの形式が不正です';
        }
        
        return $issues;
    }
    
    /**
     * テストリクエストの送信
     */
    public static function test_request() {
        require_once HOPLINK_PLUGIN_DIR . 'includes/class-hoplink-amazon-api.php';
        
        $api = new HopLink_Amazon_API();
        
        // デバッグモードを有効化
        $api->set_debug_mode(true);
        
        // 認証情報の検証
        $credential_issues = $api->validate_credentials();
        if (!empty($credential_issues)) {
            return array(
                'success' => false,
                'error' => 'Invalid credentials',
                'credential_issues' => $credential_issues
            );
        }
        
        // エラーログを有効化
        add_action('http_api_debug', function($response, $context, $class, $args, $url) {
            error_log('Amazon API Request URL: ' . $url);
            error_log('Amazon API Request Headers: ' . print_r($args['headers'], true));
            if (is_wp_error($response)) {
                error_log('Amazon API Error: ' . $response->get_error_message());
            } else {
                error_log('Amazon API Response Code: ' . wp_remote_retrieve_response_code($response));
                error_log('Amazon API Response Body: ' . wp_remote_retrieve_body($response));
            }
        }, 10, 5);
        
        // 簡単なキーワードでテスト
        $start_time = microtime(true);
        $results = $api->search_items('beer', 1);
        $end_time = microtime(true);
        
        return array(
            'success' => !empty($results),
            'product_count' => count($results),
            'first_product' => !empty($results) ? $results[0] : null,
            'execution_time' => round(($end_time - $start_time) * 1000, 2) . 'ms',
            'credential_issues' => $credential_issues
        );
    }
    
    /**
     * 署名プロセスのテスト
     */
    public static function test_signature_process() {
        require_once HOPLINK_PLUGIN_DIR . 'includes/class-hoplink-amazon-api.php';
        
        $api = new HopLink_Amazon_API();
        $api->set_debug_mode(true);
        
        // テスト用のパラメータ
        $test_params = array(
            'operation' => 'SearchItems',
            'timestamp' => gmdate('Ymd\THis\Z'),
            'date' => gmdate('Ymd'),
            'payload' => array(
                'Keywords' => 'test',
                'SearchIndex' => 'All',
                'ItemCount' => 1,
                'PartnerTag' => get_option('hoplink_amazon_partner_tag'),
                'PartnerType' => 'Associates',
                'Marketplace' => 'www.amazon.co.jp',
                'Resources' => array('ItemInfo.Title')
            )
        );
        
        // デバッグ情報を収集
        ob_start();
        error_log('=== Amazon PA-API Signature Process Test ===');
        error_log('Test Parameters: ' . print_r($test_params, true));
        
        // 実際のリクエストを実行（デバッグモードで詳細ログが出力される）
        $results = $api->search_items('test', 1);
        
        $debug_output = ob_get_clean();
        
        return array(
            'test_parameters' => $test_params,
            'request_success' => !empty($results),
            'debug_output' => $debug_output
        );
    }
    
    /**
     * エラーレスポンスの詳細解析
     */
    public static function analyze_error_response($response_body) {
        $data = json_decode($response_body, true);
        
        if (!$data) {
            return array(
                'error' => 'Invalid JSON response',
                'raw_response' => $response_body
            );
        }
        
        $analysis = array(
            'has_errors' => isset($data['Errors']),
            'error_count' => isset($data['Errors']) ? count($data['Errors']) : 0,
            'errors' => array()
        );
        
        if (isset($data['Errors'])) {
            foreach ($data['Errors'] as $error) {
                $error_detail = array(
                    'code' => $error['Code'] ?? 'Unknown',
                    'message' => $error['Message'] ?? 'No message',
                    'type' => $error['Type'] ?? 'Unknown'
                );
                
                // エラーコードに基づく推奨対処法
                switch ($error['Code'] ?? '') {
                    case 'InvalidSignature':
                        $error_detail['suggestion'] = 'シークレットキーが正しいか確認してください。コピー時に余分なスペースや改行が含まれていないか確認してください。また、サーバーの時刻が正しいか確認してください。';
                        break;
                    case 'InvalidParameterValue':
                        $error_detail['suggestion'] = 'リクエストパラメータの形式を確認してください。';
                        break;
                    case 'InvalidPartnerTag':
                        $error_detail['suggestion'] = 'パートナータグ（ストアID）が正しいか確認してください。アソシエイト・セントラルの右上で確認できます。';
                        break;
                    case 'UnauthorizedAccess':
                        $error_detail['suggestion'] = 'アクセスキーとシークレットキーが正しいか確認してください。';
                        break;
                    case 'AccessDenied':
                        $error_detail['suggestion'] = '【重要】新規アソシエイトの場合：180日以内に3件の売上が必要です。既存アソシエイトの場合：過去30日間に売上があるか確認してください。PA-APIの利用制限については https://webservices.amazon.com/paapi5/documentation/troubleshooting.html#efficiency-guidelines を参照してください。';
                        break;
                    case 'TooManyRequests':
                    case 'RequestThrottled':
                        $error_detail['suggestion'] = 'リクエスト頻度が制限を超えています。売上実績により制限は緩和されます。キャッシュを有効にしてください。';
                        break;
                    case 'IncompleteSignature':
                        $error_detail['suggestion'] = '認証情報が不完全です。アクセスキー、シークレットキー、パートナータグすべてが入力されているか確認してください。';
                        break;
                    case 'InvalidRequest':
                        $error_detail['suggestion'] = 'リクエストの形式が不正です。PA-API v5の仕様に準拠しているか確認してください。';
                        break;
                    case 'MissingAuthenticationToken':
                        $error_detail['suggestion'] = '認証トークンがありません。Authorizationヘッダーが正しく設定されているか確認してください。';
                        break;
                    case 'SignatureDoesNotMatch':
                        $error_detail['suggestion'] = '署名が一致しません。署名計算プロセス、特にサービス名(paapi)、リージョン(us-west-2)、タイムスタンプの形式を確認してください。';
                        break;
                    default:
                        $error_detail['suggestion'] = 'Amazon PA-APIのドキュメントを参照してください。エラーコード: ' . $error['Code'];
                }
                
                $analysis['errors'][] = $error_detail;
            }
        }
        
        return $analysis;
    }
}