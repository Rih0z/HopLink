<?php
/**
 * Amazon PA-API v5 包括的デバッグスクリプト
 * 
 * このスクリプトはWordPress環境で動作し、Amazon PA-APIの全ての設定と
 * 接続状況を詳細に診断します。
 * 
 * 使用方法：
 * 1. WordPress管理画面の「HopLink」メニューで実行、または
 * 2. このファイルを直接ブラウザでアクセス（/wp-content/plugins/hoplink-minimal/debug-amazon-comprehensive.php）
 * 
 * @since 1.0.0
 */

// WordPressの読み込み
if (!defined('ABSPATH')) {
    // WordPress環境の自動検出
    $wp_root = dirname(__FILE__);
    for ($i = 0; $i < 10; $i++) {
        if (file_exists($wp_root . '/wp-config.php')) {
            break;
        }
        $wp_root = dirname($wp_root);
    }
    
    if (!file_exists($wp_root . '/wp-config.php')) {
        die('WordPress環境が見つかりません。WordPressのルートディレクトリからアクセスしてください。');
    }
    
    require_once($wp_root . '/wp-config.php');
    require_once($wp_root . '/wp-includes/wp-db.php');
    require_once($wp_root . '/wp-includes/pluggable.php');
}

// プラグインファイルの読み込み
if (!defined('HOPLINK_PLUGIN_DIR')) {
    define('HOPLINK_PLUGIN_DIR', dirname(__FILE__) . '/');
}

require_once HOPLINK_PLUGIN_DIR . 'includes/class-hoplink-amazon-debug.php';

// HTML出力開始
?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Amazon PA-API 包括的デバッグ</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
        .container { max-width: 1200px; margin: 0 auto; }
        .section { margin-bottom: 30px; padding: 20px; border: 1px solid #ddd; border-radius: 5px; }
        .error { background-color: #ffebee; border-color: #f44336; }
        .warning { background-color: #fff3e0; border-color: #ff9800; }
        .success { background-color: #e8f5e8; border-color: #4caf50; }
        .info { background-color: #e3f2fd; border-color: #2196f3; }
        pre { background: #f5f5f5; padding: 15px; overflow: auto; border-radius: 3px; }
        .log-output { background: #000; color: #0f0; padding: 15px; max-height: 400px; overflow: auto; }
        table { width: 100%; border-collapse: collapse; margin: 10px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .status-ok { color: green; font-weight: bold; }
        .status-error { color: red; font-weight: bold; }
        .status-warning { color: orange; font-weight: bold; }
        .recommendation { background: #fff8c4; padding: 10px; margin: 5px 0; border-radius: 3px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔍 Amazon PA-API v5 包括的デバッグ診断</h1>
        <p><em>実行時刻: <?php echo date('Y-m-d H:i:s'); ?></em></p>
        
        <?php
        echo '<div class="section info">';
        echo '<h2>📋 診断開始</h2>';
        echo '<p>Amazon PA-API v5の設定、認証、接続状況を包括的に診断します...</p>';
        echo '</div>';
        
        // 包括的診断の実行
        $diagnosis = HopLink_Amazon_Debug::comprehensive_debug();
        
        // サーバー情報
        echo '<div class="section">';
        echo '<h2>🖥️ サーバー環境</h2>';
        echo '<table>';
        echo '<tr><th>項目</th><th>値</th><th>ステータス</th></tr>';
        
        $server_checks = array(
            'PHP Version' => array($diagnosis['server_info']['php_version'], version_compare($diagnosis['server_info']['php_version'], '7.4', '>=')),
            'cURL Extension' => array($diagnosis['server_info']['curl_enabled'] ? 'Enabled' : 'Disabled', $diagnosis['server_info']['curl_enabled']),
            'OpenSSL Extension' => array($diagnosis['server_info']['openssl_enabled'] ? 'Enabled' : 'Disabled', $diagnosis['server_info']['openssl_enabled']),
            'JSON Extension' => array($diagnosis['server_info']['json_enabled'] ? 'Enabled' : 'Disabled', $diagnosis['server_info']['json_enabled']),
            'WordPress Version' => array($diagnosis['server_info']['wordpress_version'], true),
            'Timezone' => array($diagnosis['server_info']['timezone'], true),
            'Current UTC Time' => array($diagnosis['server_info']['current_utc_time'], true)
        );
        
        foreach ($server_checks as $name => $info) {
            echo '<tr>';
            echo '<td>' . $name . '</td>';
            echo '<td>' . $info[0] . '</td>';
            echo '<td class="' . ($info[1] ? 'status-ok">✓ OK' : 'status-error">✗ ERROR') . '</td>';
            echo '</tr>';
        }
        echo '</table>';
        echo '</div>';
        
        // API設定情報
        echo '<div class="section">';
        echo '<h2>⚙️ API設定</h2>';
        echo '<table>';
        foreach ($diagnosis['api_config'] as $key => $value) {
            echo '<tr><td>' . ucfirst(str_replace('_', ' ', $key)) . '</td><td><code>' . $value . '</code></td></tr>';
        }
        echo '</table>';
        echo '</div>';
        
        // 認証情報チェック
        $credential_class = empty($diagnosis['credential_check']['issues']) ? 'success' : 'error';
        echo '<div class="section ' . $credential_class . '">';
        echo '<h2>🔐 認証情報チェック</h2>';
        
        if (!empty($diagnosis['credential_check']['issues'])) {
            echo '<div class="status-error"><strong>認証情報に問題があります:</strong></div>';
            echo '<ul>';
            foreach ($diagnosis['credential_check']['issues'] as $issue) {
                echo '<li>' . $issue . '</li>';
            }
            echo '</ul>';
        } else {
            echo '<div class="status-ok"><strong>✓ 認証情報は正常です</strong></div>';
        }
        
        echo '<table>';
        echo '<tr><th>項目</th><th>ステータス</th></tr>';
        $cred_checks = array(
            'Access Key Set' => $diagnosis['credential_check']['access_key_set'],
            'Access Key Length (20)' => $diagnosis['credential_check']['access_key_length'] === 20,
            'Access Key Format' => $diagnosis['credential_check']['access_key_format'],
            'Secret Key Set' => $diagnosis['credential_check']['secret_key_set'],
            'Secret Key Length (40)' => $diagnosis['credential_check']['secret_key_length'] === 40,
            'Partner Tag Set' => $diagnosis['credential_check']['partner_tag_set'],
            'Partner Tag Format' => $diagnosis['credential_check']['partner_tag_format']
        );
        
        foreach ($cred_checks as $name => $status) {
            echo '<tr>';
            echo '<td>' . $name . '</td>';
            echo '<td class="' . ($status ? 'status-ok">✓ OK' : 'status-error">✗ FAIL') . '</td>';
            echo '</tr>';
        }
        echo '</table>';
        echo '</div>';
        
        // 接続テスト
        $connectivity_class = $diagnosis['connectivity_test']['success'] ? 'success' : 'error';
        echo '<div class="section ' . $connectivity_class . '">';
        echo '<h2>🌐 接続テスト</h2>';
        
        if ($diagnosis['connectivity_test']['success']) {
            echo '<div class="status-ok">✓ Amazon APIエンドポイントへの接続成功</div>';
            echo '<p>レスポンスコード: ' . $diagnosis['connectivity_test']['response_code'] . '</p>';
        } else {
            echo '<div class="status-error">✗ Amazon APIエンドポイントへの接続失敗</div>';
            echo '<p>エラー: ' . $diagnosis['connectivity_test']['error'] . '</p>';
            echo '<p>エラーコード: ' . $diagnosis['connectivity_test']['error_code'] . '</p>';
        }
        echo '</div>';
        
        // APIテスト結果
        if (!isset($diagnosis['api_test']['skipped'])) {
            $api_class = $diagnosis['api_test']['success'] ? 'success' : 'error';
            echo '<div class="section ' . $api_class . '">';
            echo '<h2>🔄 APIテスト結果</h2>';
            
            if ($diagnosis['api_test']['success']) {
                echo '<div class="status-ok">✓ Amazon PA-API呼び出し成功</div>';
                echo '<p>取得商品数: ' . $diagnosis['api_test']['product_count'] . '</p>';
                echo '<p>実行時間: ' . $diagnosis['api_test']['execution_time'] . '</p>';
            } else {
                echo '<div class="status-error">✗ Amazon PA-API呼び出し失敗</div>';
                echo '<p>実行時間: ' . $diagnosis['api_test']['execution_time'] . '</p>';
                
                // デバッグ情報がある場合は表示
                if (isset($diagnosis['api_test']['debug_info']['debug_logs'])) {
                    $debug_logs = $diagnosis['api_test']['debug_info']['debug_logs'];
                    
                    if (isset($debug_logs['response_code'])) {
                        echo '<p><strong>HTTPレスポンスコード:</strong> ' . $debug_logs['response_code'] . '</p>';
                    }
                    
                    if (isset($debug_logs['api_errors']) && !empty($debug_logs['api_errors'])) {
                        echo '<h4>APIエラー詳細:</h4>';
                        foreach ($debug_logs['api_errors'] as $error) {
                            echo '<div class="recommendation">';
                            echo '<strong>エラーコード:</strong> ' . ($error['Code'] ?? 'Unknown') . '<br>';
                            echo '<strong>メッセージ:</strong> ' . ($error['Message'] ?? 'No message') . '<br>';
                            echo '<strong>タイプ:</strong> ' . ($error['Type'] ?? 'Unknown');
                            echo '</div>';
                        }
                    }
                }
            }
            echo '</div>';
        } else {
            echo '<div class="section warning">';
            echo '<h2>⚠️ APIテストはスキップされました</h2>';
            echo '<p>理由: ' . $diagnosis['api_test']['reason'] . '</p>';
            echo '</div>';
        }
        
        // 推奨事項
        echo '<div class="section info">';
        echo '<h2>💡 推奨事項</h2>';
        
        if (!empty($diagnosis['recommendations'])) {
            foreach ($diagnosis['recommendations'] as $rec) {
                $priority_class = '';
                switch ($rec['priority']) {
                    case 'critical': $priority_class = 'error'; break;
                    case 'high': $priority_class = 'warning'; break;
                    default: $priority_class = 'info'; break;
                }
                
                echo '<div class="recommendation ' . $priority_class . '">';
                echo '<strong>[' . strtoupper($rec['priority']) . '] ' . ucfirst($rec['category']) . ':</strong> ';
                echo $rec['message'];
                echo '</div>';
            }
        }
        echo '</div>';
        
        // ログファイル情報
        echo '<div class="section">';
        echo '<h2>📄 ログファイル情報</h2>';
        $log_files = HopLink_Amazon_Debug::get_log_file_paths();
        
        echo '<table>';
        echo '<tr><th>ファイル名</th><th>存在</th><th>サイズ</th><th>最終更新</th><th>パス</th></tr>';
        foreach ($log_files as $name => $info) {
            echo '<tr>';
            echo '<td>' . $name . '</td>';
            echo '<td class="' . ($info['exists'] ? 'status-ok">✓' : 'status-error">✗') . '</td>';
            echo '<td>' . ($info['exists'] ? number_format($info['size']) . ' bytes' : '-') . '</td>';
            echo '<td>' . ($info['modified'] ?: '-') . '</td>';
            echo '<td><code>' . $info['path'] . '</code></td>';
            echo '</tr>';
        }
        echo '</table>';
        echo '</div>';
        
        // 生の診断データ
        echo '<div class="section">';
        echo '<h2>🔧 詳細診断データ (JSON)</h2>';
        echo '<pre>';
        echo htmlspecialchars(json_encode($diagnosis, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        echo '</pre>';
        echo '</div>';
        
        // 最新ログの表示
        $debug_log = WP_CONTENT_DIR . '/debug-hoplink-amazon.log';
        if (file_exists($debug_log)) {
            echo '<div class="section">';
            echo '<h2>📝 最新のデバッグログ</h2>';
            $lines = file($debug_log);
            $recent_lines = array_slice($lines, -100);
            
            echo '<div class="log-output">';
            foreach ($recent_lines as $line) {
                echo htmlspecialchars($line) . '<br>';
            }
            echo '</div>';
            echo '</div>';
        }
        ?>
        
        <div class="section info">
            <h2>📞 サポート情報</h2>
            <p>この診断結果をもとに、以下の情報を確認してください：</p>
            <ul>
                <li><strong>認証情報の取得:</strong> <a href="https://affiliate.amazon.co.jp/assoc_credentials/home" target="_blank">アソシエイト・セントラル</a></li>
                <li><strong>PA-API利用条件:</strong> <a href="https://affiliate.amazon.co.jp/help/node/topic/GFSZ6Y63YJXJ4NFJ" target="_blank">公式ドキュメント</a></li>
                <li><strong>売上実績要件:</strong> 新規アソシエイトは180日以内に3件の売上が必要</li>
                <li><strong>API制限:</strong> 既存アソシエイトも過去30日の売上が必要</li>
            </ul>
        </div>
        
        <div class="section">
            <h2>🔄 再実行</h2>
            <p><a href="<?php echo $_SERVER['REQUEST_URI']; ?>" style="padding: 10px 20px; background: #0073aa; color: white; text-decoration: none; border-radius: 3px;">診断を再実行</a></p>
        </div>
    </div>
</body>
</html>