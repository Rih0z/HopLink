<?php
/**
 * API設定ファイル（このファイルはGitにコミットされません）
 */

// 楽天API設定
define('HOPLINK_RAKUTEN_APP_ID', '1013646616942500290');
define('HOPLINK_RAKUTEN_AFFILIATE_ID', '20a2fc9d.5c6c02f2.20a2fc9e.541a36d0');

// Amazon API設定
define('HOPLINK_AMAZON_ACCESS_KEY', 'AKPAM7HVCY1749420406');
define('HOPLINK_AMAZON_SECRET_KEY', 'HuYD84dwEnjxys3cnTKGI/Dju/RcHBhDRcWwJLYw');
define('HOPLINK_AMAZON_PARTNER_TAG', 'rih0z-22'); // AmazonアソシエイトのトラッキングID