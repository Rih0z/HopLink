<?php
/**
 * Amazon PA-API v5 テストスクリプト
 * 
 * このスクリプトは、Amazon PA-API v5の認証プロセスを段階的に検証するためのものです。
 * WordPressの環境外でも実行できるよう、最小限の依存関係で構成されています。
 * 
 * 使用方法:
 * 1. 下記の定数にアソシエイト・セントラルから取得した認証情報を設定
 * 2. コマンドラインまたはブラウザでこのスクリプトを実行
 * 
 * @since 1.0.0
 */

// エラー表示を有効化
error_reporting(E_ALL);
ini_set('display_errors', 1);

// 認証情報（実際の値に置き換えてください）
define('TEST_ACCESS_KEY', 'YOUR_ACCESS_KEY_HERE');  // 20文字のアクセスキー（例: AKIAIOSFODNN7EXAMPLE）
define('TEST_SECRET_KEY', 'YOUR_SECRET_KEY_HERE');  // 40文字のシークレットキー
define('TEST_PARTNER_TAG', 'YOUR_PARTNER_TAG_HERE'); // パートナータグ（ストアID）

// PA-API v5のエンドポイント設定（日本）
define('TEST_HOST', 'webservices.amazon.co.jp');
define('TEST_REGION', 'us-west-2'); // PA-API v5では全地域でus-west-2を使用

class AmazonPAAPITest {
    
    private $access_key;
    private $secret_key;
    private $partner_tag;
    private $host;
    private $region;
    
    public function __construct() {
        $this->access_key = TEST_ACCESS_KEY;
        $this->secret_key = TEST_SECRET_KEY;
        $this->partner_tag = TEST_PARTNER_TAG;
        $this->host = TEST_HOST;
        $this->region = TEST_REGION;
    }
    
    /**
     * テスト実行
     */
    public function run_test() {
        echo "=== Amazon PA-API v5 認証テスト ===\n\n";
        
        // テスト実行頻度の制御
        $last_test_file = __DIR__ . '/.last_api_test';
        $current_time = time();
        $min_interval = 60; // 1分間隔
        
        if (file_exists($last_test_file)) {
            $last_test_time = (int)file_get_contents($last_test_file);
            if (($current_time - $last_test_time) < $min_interval) {
                $remaining_time = $min_interval - ($current_time - $last_test_time);
                echo "\n⚠️  テスト実行制限\n";
                echo "連続テストはAPI制限に達する可能性があります。\n";
                echo "あと {$remaining_time} 秒待ってから再実行してください。\n\n";
                return;
            }
        }
        
        // テスト実行時刻を記録
        file_put_contents($last_test_file, $current_time);
        
        echo "🕒 テスト実行時刻: " . date('Y-m-d H:i:s') . "\n";
        echo "⚠️  次回テストまで {$min_interval} 秒間あけてください\n\n";
        
        // Step 1: 認証情報の検証
        echo "[Step 1] 認証情報の検証\n";
        $this->validate_credentials();
        echo "\n";
        
        // Step 2: タイムスタンプ生成
        echo "[Step 2] タイムスタンプ生成\n";
        $timestamp = gmdate('Ymd\THis\Z');
        $date = gmdate('Ymd');
        echo "Timestamp: $timestamp\n";
        echo "Date: $date\n";
        echo "Current UTC time: " . gmdate('Y-m-d H:i:s') . "\n";
        echo "\n";
        
        // Step 3: リクエストパラメータ準備
        echo "[Step 3] リクエストパラメータ準備\n";
        $operation = 'SearchItems';
        $path = '/paapi5/searchitems';
        
        $payload = array(
            'Keywords' => 'test',
            'SearchIndex' => 'All',
            'ItemCount' => 1,
            'PartnerTag' => $this->partner_tag,
            'PartnerType' => 'Associates',
            'Marketplace' => 'www.amazon.co.jp',
            'Resources' => array(
                'ItemInfo.Title',
                'Offers.Listings.Price'
            )
        );
        
        $payload_json = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        echo "Payload JSON:\n$payload_json\n";
        echo "Payload length: " . strlen($payload_json) . " bytes\n";
        echo "\n";
        
        // Step 4: ヘッダー準備
        echo "[Step 4] ヘッダー準備\n";
        $headers = array(
            'content-encoding' => 'amz-1.0',
            'content-type' => 'application/json; charset=utf-8',
            'host' => $this->host,
            'x-amz-date' => $timestamp,
            'x-amz-target' => 'com.amazon.paapi5.v1.ProductAdvertisingAPIv1.' . $operation
        );
        
        foreach ($headers as $key => $value) {
            echo "$key: $value\n";
        }
        echo "\n";
        
        // Step 5: 正規リクエスト作成
        echo "[Step 5] 正規リクエスト作成\n";
        $canonical_request = $this->create_canonical_request('POST', $path, '', $headers, $payload_json);
        echo "Canonical Request:\n" . str_replace("\n", '\n', $canonical_request) . "\n\n";
        echo "Canonical Request Hash: " . hash('sha256', $canonical_request) . "\n";
        echo "\n";
        
        // Step 6: 署名文字列作成
        echo "[Step 6] 署名文字列作成\n";
        $string_to_sign = $this->create_string_to_sign($timestamp, $date, $canonical_request);
        echo "String to Sign:\n" . str_replace("\n", '\n', $string_to_sign) . "\n\n";
        
        // Step 7: 署名計算
        echo "[Step 7] 署名計算\n";
        $signature = $this->calculate_signature($date, $string_to_sign);
        echo "Signature: $signature\n";
        echo "\n";
        
        // Step 8: Authorizationヘッダー作成
        echo "[Step 8] Authorizationヘッダー作成\n";
        $auth_header = $this->create_authorization_header($date, $headers, $signature);
        echo "Authorization Header:\n$auth_header\n";
        echo "\n";
        
        // Step 9: 実際のAPIリクエスト送信
        echo "[Step 9] APIリクエスト送信\n";
        $this->send_request($path, $headers, $payload_json, $auth_header);
    }
    
    /**
     * 認証情報の検証
     */
    private function validate_credentials() {
        $issues = array();
        
        // アクセスキー
        if ($this->access_key === 'YOUR_ACCESS_KEY_HERE') {
            $issues[] = "アクセスキーが設定されていません";
        } elseif (strlen($this->access_key) !== 20) {
            $issues[] = "アクセスキーの長さが不正です（20文字である必要があります）";
        } elseif (!preg_match('/^[A-Z0-9]{20}$/', $this->access_key)) {
            $issues[] = "アクセスキーの形式が不正です（大文字英数字20文字）";
        }
        
        // シークレットキー
        if ($this->secret_key === 'YOUR_SECRET_KEY_HERE') {
            $issues[] = "シークレットキーが設定されていません";
        } elseif (strlen($this->secret_key) !== 40) {
            $issues[] = "シークレットキーの長さが不正です（40文字である必要があります）";
        }
        
        // パートナータグ
        if ($this->partner_tag === 'YOUR_PARTNER_TAG_HERE') {
            $issues[] = "パートナータグが設定されていません";
        } elseif (!preg_match('/^[a-zA-Z0-9\-]+$/', $this->partner_tag)) {
            $issues[] = "パートナータグの形式が不正です";
        }
        
        if (!empty($issues)) {
            echo "認証情報に問題があります:\n";
            foreach ($issues as $issue) {
                echo "  - $issue\n";
            }
            echo "\n⚠️  実際の認証情報を設定してから再度実行してください。\n";
            exit(1);
        } else {
            echo "✓ 認証情報の形式は正しいです\n";
        }
    }
    
    /**
     * 正規リクエスト作成
     */
    private function create_canonical_request($method, $path, $query, $headers, $payload) {
        $canonical_headers = '';
        $signed_headers_array = array();
        
        // ヘッダーを小文字にしてソート
        $sorted_headers = array();
        foreach ($headers as $key => $value) {
            $sorted_headers[strtolower($key)] = trim($value);
        }
        ksort($sorted_headers);
        
        foreach ($sorted_headers as $key => $value) {
            $canonical_headers .= $key . ':' . $value . "\n";
            $signed_headers_array[] = $key;
        }
        
        $signed_headers = implode(';', $signed_headers_array);
        $payload_hash = hash('sha256', $payload);
        
        $canonical_request = implode("\n", array(
            $method,
            $path,
            $query,
            $canonical_headers,
            $signed_headers,
            $payload_hash
        ));
        
        return $canonical_request;
    }
    
    /**
     * 署名文字列作成
     */
    private function create_string_to_sign($timestamp, $date, $canonical_request) {
        $credential_scope = $date . '/' . $this->region . '/ProductAdvertisingAPI/aws4_request';
        $canonical_request_hash = hash('sha256', $canonical_request);
        
        $string_to_sign = implode("\n", array(
            'AWS4-HMAC-SHA256',
            $timestamp,
            $credential_scope,
            $canonical_request_hash
        ));
        
        return $string_to_sign;
    }
    
    /**
     * 署名計算
     */
    private function calculate_signature($date, $string_to_sign) {
        $k_date = hash_hmac('sha256', $date, 'AWS4' . $this->secret_key, true);
        $k_region = hash_hmac('sha256', $this->region, $k_date, true);
        $k_service = hash_hmac('sha256', 'ProductAdvertisingAPI', $k_region, true);
        $k_signing = hash_hmac('sha256', 'aws4_request', $k_service, true);
        $signature = hash_hmac('sha256', $string_to_sign, $k_signing);
        
        return $signature;
    }
    
    /**
     * Authorizationヘッダー作成
     */
    private function create_authorization_header($date, $headers, $signature) {
        $signed_headers_array = array();
        foreach ($headers as $key => $value) {
            $signed_headers_array[] = strtolower($key);
        }
        sort($signed_headers_array);
        $signed_headers = implode(';', $signed_headers_array);
        
        $credential_scope = $date . '/' . $this->region . '/ProductAdvertisingAPI/aws4_request';
        
        return sprintf(
            'AWS4-HMAC-SHA256 Credential=%s/%s, SignedHeaders=%s, Signature=%s',
            $this->access_key,
            $credential_scope,
            $signed_headers,
            $signature
        );
    }
    
    /**
     * APIリクエスト送信
     */
    private function send_request($path, $headers, $payload_json, $auth_header) {
        $url = 'https://' . $this->host . $path;
        echo "Request URL: $url\n\n";
        
        // cURLを使用してリクエスト送信
        $ch = curl_init();
        
        $curl_headers = array();
        foreach ($headers as $key => $value) {
            // HTTPヘッダーの大文字小文字を適切に設定
            $header_name = str_replace(' ', '-', ucwords(str_replace('-', ' ', $key)));
            if ($key === 'x-amz-date') $header_name = 'X-Amz-Date';
            if ($key === 'x-amz-target') $header_name = 'X-Amz-Target';
            $curl_headers[] = $header_name . ': ' . $value;
        }
        $curl_headers[] = 'Authorization: ' . $auth_header;
        
        echo "Request Headers:\n";
        foreach ($curl_headers as $header) {
            echo "  $header\n";
        }
        echo "\n";
        
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload_json);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $curl_headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HEADER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        $info = curl_getinfo($ch);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            echo "cURL Error: $error\n";
            return;
        }
        
        $header_size = $info['header_size'];
        $response_headers = substr($response, 0, $header_size);
        $response_body = substr($response, $header_size);
        
        echo "Response Code: " . $info['http_code'] . "\n\n";
        echo "Response Headers:\n$response_headers\n";
        echo "Response Body:\n$response_body\n\n";
        
        // レスポンス解析
        $data = json_decode($response_body, true);
        if ($info['http_code'] !== 200) {
            echo "=== エラー詳細 ===\n";
            if (isset($data['Errors'])) {
                foreach ($data['Errors'] as $error) {
                    echo "Error Code: " . ($error['Code'] ?? 'Unknown') . "\n";
                    echo "Error Message: " . ($error['Message'] ?? 'No message') . "\n";
                    echo "Error Type: " . ($error['Type'] ?? 'Unknown') . "\n";
                    echo "\n";
                    
                    // エラーに応じた対処法
                    $this->suggest_solution($error['Code'] ?? '');
                }
            } elseif (isset($data['__type'])) {
                echo "AWS Error Type: " . $data['__type'] . "\n";
                echo "AWS Error Message: " . ($data['message'] ?? 'No message') . "\n";
            }
        } else {
            echo "✓ リクエスト成功！\n";
            if (isset($data['SearchResult']['Items']) && count($data['SearchResult']['Items']) > 0) {
                echo "取得した商品:\n";
                foreach ($data['SearchResult']['Items'] as $item) {
                    echo "  - " . ($item['ItemInfo']['Title']['DisplayValue'] ?? 'タイトルなし') . "\n";
                }
            }
        }
    }
    
    /**
     * エラーに応じた解決策を提案
     */
    private function suggest_solution($error_code) {
        $suggestions = array(
            'InvalidSignature' => 'シークレットキーが正しいか確認してください。コピー時に余分なスペースや改行が含まれていないか確認してください。',
            'InvalidParameterValue' => 'リクエストパラメータの形式を確認してください。',
            'InvalidPartnerTag' => 'パートナータグ（ストアID）が正しいか確認してください。アソシエイト・セントラルの右上で確認できます。',
            'UnauthorizedAccess' => 'アクセスキーとシークレットキーが正しいか確認してください。',
            'AccessDenied' => '【重要】新規アソシエイトの場合：180日以内に3件の売上が必要です。既存アソシエイトの場合：過去30日間に売上があるか確認してください。',
            'TooManyRequests' => 'リクエスト頻度が制限を超えています。売上実績により制限は緩和されます。',
            'SignatureDoesNotMatch' => '署名が一致しません。タイムスタンプ、リージョン、サービス名を確認してください。'
        );
        
        if (isset($suggestions[$error_code])) {
            echo "💡 対処法: " . $suggestions[$error_code] . "\n\n";
        }
    }
}

// テスト実行
$test = new AmazonPAAPITest();
$test->run_test();